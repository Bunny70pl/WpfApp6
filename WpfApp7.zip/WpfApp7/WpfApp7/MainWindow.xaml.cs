﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string liczba1 = liczba.Text;
            string figurka = figura.Text;
            int boki = 1;
            if(int.TryParse(liczba1 , out int result))
            {
                if(result >= 0)
                {
                    if (figurka == "trojkat")
                    {
                        boki = 3;
                        kwadracik.Visibility = Visibility.Hidden;
                    }
                    else if (figurka == "kwadrat")
                    {
                        kwadracik.Visibility = Visibility.Visible;
                        boki = 4;
                        kwadracik.Width = result * 10;
                        kwadracik.Height = result * 10;

                    }
                    else if (figurka == "pieciokat")
                    {
                        boki = 5;
                        kwadracik.Visibility = Visibility.Hidden;
                    }
                    result *= boki;
                    MessageBox.Show("Obwod to: " + result.ToString() );
                }
                else
                {
                    MessageBox.Show("Podaj liczbe > 0");
                }

            }
            else
            {
                MessageBox.Show("Podaj liczbe");
            }
        }

        private void figura_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(liczba2.Text, out double result))
            {
                if (Euro.IsChecked==true)
                {
                    result *= 0.23;
                    MessageBox.Show(result.ToString());
                }else if (Franki.IsChecked == true)
                {
                    result *= 0.22;
                    MessageBox.Show(result.ToString());
                }
                else if (Dolary.IsChecked == true)
                {
                    result *= 0.24;
                    MessageBox.Show(result.ToString());
                }
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if(double.TryParse(temperatura.Text, out double result))
            {
                if (celw.IsChecked==true)
                {
                    if (celz.IsChecked == true)
                    {
                        result += 0;
                    }else if(farz.IsChecked == true)
                    {
                        result = ((result-32)*5)/9;
                    }else if(kelz.IsChecked == true)
                    {
                        result = result + 273.15;
                    }
                }
                else if(farw.IsChecked==true)
                {
                    if (celz.IsChecked == true)
                    {
                        result += (result*(9/5))+32;
                    }
                    else if (farz.IsChecked == true)
                    {
                        result = result;
                    }
                    else if (kelz.IsChecked == true)
                    {
                        result = ((result-32)*5)/9+273.15;
                    }
                }
                else if (kelw.IsChecked == true)
                {
                    if (celz.IsChecked == true)
                    {
                        result = result + 273.15 ;
                    }
                    else if (farz.IsChecked == true)
                    {
                        result = (result-273.15)*(9/5)+32;
                    }
                    else if (kelz.IsChecked == true)
                    {
                        result = result;
                    }
                }
                tekstDoWyniku.Text = "Wynik to: " + result;
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (long.TryParse(liczba1kalk1.Text, out long result) && long.TryParse(liczba1kalk2.Text, out long result2))
            {
                int wynik = 1;
                for (int i = 1; i <= result; i++)
                {
                    wynik *= i;
                }
                MessageBox.Show("silna to: " + wynik.ToString());
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (long.TryParse(liczba1kalk1.Text, out long result) && long.TryParse(liczba1kalk2.Text, out long result2))
            {
                if(result == 0 || result2 == 0)
                {
                    result += result2;
                }
                while(result != result2)
                {
                    if (result >= result2)
                    {
                        result -= result2;
                    }
                    else
                    {
                        result2 -= result;
                    }
                }
                MessageBox.Show("nwd to: " + result.ToString());
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(liczba1kalk1.Text, out double result) && double.TryParse(liczba1kalk2.Text, out double result2))
            {
                double wynik = Math.Pow(result,result2);
                MessageBox.Show("potega to: " + wynik.ToString());
            }
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(liczba1kalk1.Text, out double result) && double.TryParse(liczba1kalk2.Text, out double result2))
            {
                double max = 0;
                if(result < result2)
                {
                    max = result2;
                }
                else
                {
                    max = result;
                }
                bool[] tab = new bool[(int)max];
                tab[0] = true;
                tab[1] = true;
                for (int i = 2; i <max; i++)
                {
                    tab[i] = true;
                }
                for (int i = 2; i < Math.Sqrt(max); i++)
                {
                    if (tab[i] == true)
                    {
                        for (int j = i; j < max; j += i)
                        {
                            tab[j] = false;
                        }
                    }
                }
                List<int> tabPierwszyschWPrzediale = new List<int>();
                string anc = " ";
                for (int i = (int)result; i < Math.Sqrt(max); i++)
                {
                    if (tab[i] == true)
                    {
                        tabPierwszyschWPrzediale.Add(i);
                         anc += tab[i].ToString();
                    }
                }
                MessageBox.Show(anc.ToString());
            }
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(liczba1kalk1.Text, out double result) && double.TryParse(liczba1kalk2.Text, out double result2))
            {
                double max,min2 = 1;
                if (result < result2)
                {
                    min2 = result;
                    max = result2;
                }
                else
                {
                    min2 = result2;
                    max = result;
                }
                int suma = 0;
                for(int i = (int)min2; i < max; i++)
                {
                    suma += i;
                }
            }
        }
    }
}
