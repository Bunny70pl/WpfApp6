﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string liczba1 = liczba.Text;
            string figurka = figura.Text;
            int boki = 1;
            if(int.TryParse(liczba1 , out int result))
            {
                if(result >= 0)
                {
                    if (figurka == "trojkat")
                    {
                        boki = 3;
                        kwadracik.Visibility = Visibility.Hidden;
                    }
                    else if (figurka == "kwadrat")
                    {
                        kwadracik.Visibility = Visibility.Visible;
                        boki = 4;
                        kwadracik.Width = result * 10;
                        kwadracik.Height = result * 10;

                    }
                    else if (figurka == "pieciokat")
                    {
                        boki = 5;
                        kwadracik.Visibility = Visibility.Hidden;
                    }
                    result *= boki;
                    MessageBox.Show("Obwod to: " + result.ToString() );
                }
                else
                {
                    MessageBox.Show("Podaj liczbe > 0");
                }

            }
            else
            {
                MessageBox.Show("Podaj liczbe");
            }
        }

        private void figura_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(liczba2.Text, out double result))
            {
                if (Euro.IsChecked==true)
                {
                    result *= 0.23;
                    MessageBox.Show(result.ToString());
                }else if (Franki.IsChecked == true)
                {
                    result *= 0.22;
                    MessageBox.Show(result.ToString());
                }
                else if (Dolary.IsChecked == true)
                {
                    result *= 0.24;
                    MessageBox.Show(result.ToString());
                }
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }
    }
}
